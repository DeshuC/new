package com.example.librarymanagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DbHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "LibraryManager";
    private static final String TABLE_BRANCHES = "branches";
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_ADDRESS = "address";

    public DbHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_BRANCHES_TABLE = "CREATE TABLE " + TABLE_BRANCHES + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_NAME + " TEXT,"
                + KEY_ADDRESS + " TEXT" + ")";
        db.execSQL(CREATE_BRANCHES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BRANCHES);
        onCreate(db);
    }

    // CRUD Operations for Branches

    // Add a new branch
    public void addBranch(Branch branch) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, branch.getName());


        db.insert(TABLE_BRANCHES, null, values);
        db.close();
    }

    // Get all branches
    public List<Branch> getAllBranches() {
        List<Branch> branchList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_BRANCHES;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Branch branch = new Branch();
                branch.setId(Integer.parseInt(cursor.getString(0)));
                branch.setName(cursor.getString(1));
                branchList.add(branch);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return branchList;
    }

    // Update a branch
    public int updateBranch(Branch branch) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, branch.getName());

        return db.update(TABLE_BRANCHES, values, KEY_ID + " = ?",
                new String[]{String.valueOf(branch.getId())});
    }

    // Delete a branch
    public void deleteBranch(Branch branch) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_BRANCHES, KEY_ID + " = ?",
                new String[]{String.valueOf(branch.getId())});
        db.close();
    }
}

