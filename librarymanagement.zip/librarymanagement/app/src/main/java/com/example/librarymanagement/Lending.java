package com.example.librarymanagement;

public class Lending {
    private int id;
    private int memberId;
    private int bookCopyId;
    private String issueDate;
    private String returnDate;

    // Constructor
    public Lending(int id, int memberId, int bookCopyId, String issueDate, String returnDate) {
        this.id = id;
        this.memberId = memberId;
        this.bookCopyId = bookCopyId;
        this.issueDate = issueDate;
        this.returnDate = returnDate;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public int getBookCopyId() {
        return bookCopyId;
    }

    public void setBookCopyId(int bookCopyId) {
        this.bookCopyId = bookCopyId;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    // toString method
    @Override
    public String toString() {
        return "Lending{" +
                "id=" + id +
                ", memberId=" + memberId +
                ", bookCopyId=" + bookCopyId +
                ", issueDate='" + issueDate + '\'' +
                ", returnDate='" + returnDate + '\'' +
                '}';
    }
}

