package com.example.librarymanagement;

public class BookCopy {
    private int id;
    private int bookId;
    private String copyNumber;
    private boolean available;

    // Constructor
    public BookCopy(int id, int bookId, String copyNumber, boolean available) {
        this.id = id;
        this.bookId = bookId;
        this.copyNumber = copyNumber;
        this.available = available;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getCopyNumber() {
        return copyNumber;
    }

    public void setCopyNumber(String copyNumber) {
        this.copyNumber = copyNumber;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}

