package com.example.librarymanagement;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class BranchAdapter extends ArrayAdapter<Branch> {

    private Context context;
    private int resource;
    private List<Branch> branches;

    public BranchAdapter(Context context, int resource, List<Branch> branches) {
        super(context, resource, branches);
        this.context = context;
        this.resource = resource;
        this.branches = branches;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(resource, parent, false);
        }

        Branch branch = branches.get(position);

        TextView nameTextView = convertView.findViewById(R.id.edit_branch_name);

        nameTextView.setText(branch.getName());


        return convertView;
    }
}

